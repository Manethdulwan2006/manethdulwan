function plus(){
    var numb1=document.getElementById("num1").value
    var numb2=document.getElementById("num2").value

    var answer=numb1+numb2;
    console.log(answer)
    document.getElementById("ans").value=answer
}
function mines(){
    var numb1=document.getElementById("num1").value
    var numb2=document.getElementById("num2").value

    var answer=(numb1-numb2);
    console.log(answer)
    document.getElementById("ans").value=answer
}
function multiplay(){
    var numb1=document.getElementById("num1").value
    var numb2=document.getElementById("num2").value

    var answer=(numb1*numb2);
    console.log(answer)
    document.getElementById("ans").value=answer
}
function devide(){
    var numb1=document.getElementById("num1").value
    var numb2=document.getElementById("num2").value

    var answer=(numb1/numb2);
    console.log(answer)
    document.getElementById("ans").value=answer
}